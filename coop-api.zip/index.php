<?php
require 'vendor/autoload.php';

$app = new Slim\App(array(
    'debug' => true
));

$app->get('/hello/{name}', function ($request, $response, $args) {
    return $response->write("Hello, " . $args['name']);
});

$app->run();
